-------------------------------------------------------------------------------------------
-- Name: FilPiloteZMNHJA2
-- Type: Class
-- Version:	1.0.0 RC2
-- Release date: 31-10-2014
-- Author: Jean-Christophe Vermand� (Krikroff)
-------------------------------------------------------------------------------------------

--! includes
require('common.device')
require('net.HTTPClient')
require('async')
require('fibapi')

class 'FilPiloteZMNHJA2' (Device)

FilPiloteZMNHJA2.DEFAULT_POLLING_INTERVAL = 300 --! Default Polling interval.
FilPiloteZMNHJA2.deviceID = nil                 --! Identifier of the associated module.
FilPiloteZMNHJA2.defaultMode = 0	              --! Default mode (advanced properties).
FilPiloteZMNHJA2.currentMode = nil              --! Current mode (1,2,3,4,5,6)
FilPiloteZMNHJA2.pollingInterval = nil          --! Current polling interval
FilPiloteZMNHJA2.asyncTimerInterval = nil       --! AsyncTimer Object

--! Command enum
FilPiloteZMNHJA2.command = {
  [1] = { 
    name = 'Confort', 
    value = 99
  },
  [2] = { 
    name = 'Confort -1°C', 
    value = 50
  },
  [3] = { 
    name = 'Confort -2°C',
    value = 40
  },
  [4] = { 
    name = 'Eco',
    value = 30
  },
  [5] = { 
    name = 'Hors Gel',
    value = 20
  },
  [6] = {
    name = 'Arrêt / Délestage',
    value = 0
  }
}

--! Initializes plugin object.
--!@param id: Id of the device.
function FilPiloteZMNHJA2:__init(id)
  Device.__init(self, id)
  local status, err = pcall(function()
    -- INIT
    self.deviceID = self:getDeviceID()
    self.currentMode = self:getCurrentMode()
    self.defaultMode = self:getDefaultMode()
    self.pollingInterval = self:getPollingInterval()

    if (not self.deviceID) then
      self:log('Non configuré', 1)
      -- force name
      self:setName(string.format('%d - %s', self.id, 'Qubino ZMNHJA2'))
      -- set default mode, manufacturer, model
      self:updateProperty('manufacturer', 'Qubino')
      self:updateProperty('model', 'ZMNHJA2')
      self:updateProperty('deviceIcon', 15)     
      self:updateProperty('deviceControlType', 1)
      self:updateProperty('configured', 'false')
      self:updateProperty('value', '0')
      self:updateUITemperatureSensor(0)
    else
      -- set parameters
      self:updateProperty('currentMode', self.defaultMode)
      self:updateProperty('currentModeTxt', self.command[tonumber(self.defaultMode)].name)
      self:setMode(tonumber(self.currentMode or self.defaultMode))
      -- flag
      self:updateProperty('configured', 'true')
      -- Polling timer def.
      async.timer:stopAll()
      -- Create timer interval object
      self.asyncTimerInterval = async.timer.Interval()
      -- Subscribe timer interval events
      self.asyncTimerInterval:registerEvent('start', function(time)
          --print('start timer event at ' .. time)          
        end)
      self.asyncTimerInterval:registerEvent('stop', function(time) 
          --print('stop timer event at ' .. time)
        end)
      -- Subscribe timer tick event
      self.asyncTimerInterval:registerEvent('tick', function(id, tid, difftime)
          local status, err = pcall(function()
            return self:updateModeStatus() 
          end)
          if not status then
            self:debug('tick', err)
            self:log('Polling failed!')
          end
        end)
      -- start pollingInterval
      self:startPolling()
    end

  end)
  if not status then
    self:debug('__init', err)
    self:log('Error: plugin init failed!')
  end
end

--! [public] Restart action
--!@return none
function FilPiloteZMNHJA2:restartPlugin()
  plugin.restart()
end

--! [private] Start polling, infinite timer interval (mainloop mimic)
--!@return none
function FilPiloteZMNHJA2:startPolling()
  self.asyncTimerInterval:start(self.pollingInterval * 1000)
end

--! [private] Stop polling
--!@return none
function FilPiloteZMNHJA2:stopPolling()
  self.asyncTimerInterval:stop()
end

--! [public] log value
--!@return none
function FilPiloteZMNHJA2:log(value, level)
  self:logClear(0)
  level = tonumber(level) or 0
  if (self.logTimeoutID) then
    -- Prevents multiple timeout..
    clearTimeout(self.logTimeoutID)
  end
  self.logTimeoutID = async.fn.Timeout(2000, function()
      -- perhaps a bug with logTemp properties
      --if (level==1) then
      --  self:updateProperty('logTemp', 'TxtRed')
      --end
      self:updateProperty('log', tostring(value or 'unknown'))
      self:updateProperty('log', tostring(value or 'unknown'))
      self:logClear(8000)
    end):start()
end

function FilPiloteZMNHJA2:logClear(timeout)
  if (tonumber(timeout) > 0) then
    self.logTimeoutID = async.fn.Timeout(timeout, function()
        -- perhaps a bug with logTemp properties
        --self:updateProperty('logTemp', '')
        self:updateProperty('log', '')
      end):start()
  else
    -- perhaps a bug with logTemp properties
    --self:updateProperty('logTemp', '')
    self:updateProperty('log', '')
  end
end

function FilPiloteZMNHJA2:debug(source, err)
  if (source == '' and err == '') then
    self:updateProperty('debug', '')
  else
    self:updateProperty('debug', json.encode({ source = source or 'unknown', message = err or 'unknown'}))
  end
end

function FilPiloteZMNHJA2:updateUITemperatureSensor(value)
  self:updateProperty('temperatureValue', value)
  self:updateProperty('ui.temperatureValue.caption', string.format('Température: %d %s',value, self.properties.unit))
end

--! [private] get fp device id (read property)
--!@return the device id
function FilPiloteZMNHJA2:getDeviceID()
  if (self.properties.deviceID and tostring(self.properties.deviceID) ~= '') then
    return tostring(self.properties.deviceID)
  end
  return nil
end

--! [private] get polling interval (read property)
--!@return time interval in seconds
function FilPiloteZMNHJA2:getPollingInterval()
  if (self.properties.pollingInterval and tostring(self.properties.pollingInterval) ~= '') then
    return tonumber(self.properties.pollingInterval)
  else
    return self.DEFAULT_POLLING_INTERVAL
  end
end

--! [private] get current mode(read property)
--!@return the current mode
function FilPiloteZMNHJA2:getCurrentMode()
  if (self.properties.currentMode and tostring(self.properties.currentMode) ~= '') then
    return tostring(self.properties.currentMode)
  end
  return nil
end

--! [private] get default mode(read property)
--!@return the default mode
function FilPiloteZMNHJA2:getDefaultMode()
  if (self.properties.defaultMode and tostring(self.properties.defaultMode) ~= '') then
    return tostring(self.properties.defaultMode)
  end
  return nil
end

--! [private] update config
--!@return none
function FilPiloteZMNHJA2:updateConfig()
  local status, err = pcall(function() 
    -- Start delayed task before restart the plugin eg: create child, update
    -- properties, not used with the Qubino fp plugin at this time.
    return self:restartPlugin()
  end)
  if not status then
    self:debug('updateConfig', err)
    self:log('Error: update config err!')
  end
end

--! [private] Get command by range
--!@return The command mode
function FilPiloteZMNHJA2:getCommandByRange(value)
  value = tonumber(value) or 0
  if (value >= 0 and value <= 10) then
    return 6
  elseif (value > 10 and value <= 20) then
    return 5
  elseif (value > 20 and value <= 30) then
  	return 4
  elseif (value > 30 and value <= 40) then
    return 3
  elseif (value > 40 and value <= 50) then
    return 2
  elseif (value > 50) then
    return 1
  else    
    self:log('Not supported command!')
    return nil
  end
end

--! [private] dispatch and set mode
--!param mode: mode number to dispatch
--!@return none
function FilPiloteZMNHJA2:dispatch(mode)
  mode = tonumber(mode) or self.defaultMode
  if (mode > 0 and mode <=6) then
    local function postCallbackSuccess(response)
      if (response.status == 200 or response.status == 201  or response.status == 202 and response.sizeOf > 0) then
        -- set current mode property
        self:updateProperty('currentMode', tostring(mode))
        self:updateProperty('currentModeTxt', self.command[mode].name)
        -- update lastUpdate property
        self:updateProperty('lastUpdate', os.time())
        -- update device value
        self:updateProperty('value', tostring(self.command[mode].value))  
        -- set mode in log area
        local txtMode = string.format('Mode: %s', self.command[mode].name)
        self:log(txtMode)
        self:updateProperty('ui.modeLabel.caption', txtMode)
      else
        self:debug('dispatch response', response.status .. ' - ' .. response.description)
        self:log('Transfert �chou�', 1)
      end
    end
    local function callbackError(response)
      self:debug('dispatch', response)
      self:log('Transfert �chou�', 1)
    end
    -- send z-wave command to associated device and update current Mode
    local url = '/api/devices/'.. tostring(self.deviceID) ..'/action/setValue'
    local body = json.encode({ ['args'] = { self.command[mode].value } })
    fibapi.post(url, body, postCallbackSuccess, callbackError)
  else
    self:log('Cannot dispatch, wrong value!')
  end
end
--! [private] update temperature sensor status
--!@return none
function FilPiloteZMNHJA2:updateTemperatureSensorStatus()
    local function callbackSuccess(response)
      local status, err = pcall(function() 
        if (response.status == 200 or response.status == 201  or response.status == 202 and response.sizeOf > 0) then
          local device = json.decode(response.data or {})
          -- update unit
          if (tostring(self.properties.unit)=='' or tostring(self.properties.unit)~=tostring(device.properties.unit)) then
            self:updateProperty('unit', tostring(device.properties.unit) or '')
          end
          -- update temperature value
          self:updateProperty('temperatureValue', tostring(device.properties.value))
          self:updateUITemperatureSensor(device.properties.value)
          -- update lastUpdate property
          self:updateProperty('lastUpdate', tostring(os.time())) 
        else
          self:debug('update response', response.status .. ' - ' .. response.description)
          self:log('Module inaccessible', 1)
        end
      end)
      if not status then
        self:debug('updateTemperatureSensorStatus', err)
        self:log('Polling error', 1)
      end
    end
    local function callbackError(response)
      self:debug('updateTemperatureSensorStatus', response)
      self:log('Polling error', 1)
    end
    -- get z-wave device value
    local url = '/api/devices/'.. tostring(tonumber(self.deviceID)+1)
    fibapi.get(url, callbackSuccess, callbackError)
end
--! [private] update mode status
--!@return none
function FilPiloteZMNHJA2:updateModeStatus()
    local function callbackSuccess(response)
      local status, err = pcall(function() 
        if (response.status == 200 or response.status == 201  or response.status == 202 and response.sizeOf > 0) then
          local device = json.decode(response.data or {})
          if (tostring(device.properties.dead)=='true') then
            self:updateProperty('dead', true)
          else
            if (tostring(self.properties.dead)=='true') then
              self:updateProperty('dead', false)
            end
            local mode = self:getCommandByRange(device.properties.value)
            --[[
            if (mode == 1) then
              self:updateProperty('deviceIcon', '25')
            elseif (mode == 2) then
              self:updateProperty('deviceIcon', '26')
            elseif (mode == 3) then
              self:updateProperty('deviceIcon', '27')
            end
            --]]
            -- set current mode property
            self:updateProperty('currentMode', tostring(mode))
            self:updateProperty('currentModeTxt', self.command[mode].name)
            -- update lastUpdate property
            self:updateProperty('lastUpdate', tostring(os.time()))
            -- update device value
            self:updateProperty('value', tostring(self.command[mode].value))  
            -- set mode in log area
            local txtMode = string.format('Mode: %s', self.command[mode].name)
            self:log(txtMode)
            self:updateProperty('ui.modeLabel.caption', txtMode)
          end
          self:updateTemperatureSensorStatus()     
        else
          self:debug('update response', response.status .. ' - ' .. response.description)
          self:log('Module inaccessible', 1)
        end
      end)
      if not status then
        self:debug('updateModeStatus', err)
        self:log('Polling error', 1)
      end
    end
    local function callbackError(response)
      self:debug('updateModeStatus', response)
      self:log('Polling error', 1)
    end
    -- get z-wave device value
    local url = '/api/devices/'.. tostring(self.deviceID)
    fibapi.get(url, callbackSuccess, callbackError)
end
-----------------------------------------------
-- ACTIONS
-----------------------------------------------

--! [private] set mode
--!@return none
function FilPiloteZMNHJA2:setMode(mode)
  local status, err = pcall(function() 
    return self:dispatch(mode)
  end)
  if not status then
    self:debug('setMode', err)
    self:log('Error: unable to set mode!')
  end
end
--! [private] turn ON - Confort
--!@return none
function FilPiloteZMNHJA2:turnOn()
  local status, err = pcall(function() 
    return self:dispatch(1)
  end)
  if not status then
    self:debug('turnOn', err)
    self:log('Error: unable to turnOn!')
  end
end
--! [private] turn OFF - Arr�t
--!@return none
function FilPiloteZMNHJA2:turnOff()
  local status, err = pcall(function() 
    return self:dispatch(6)
  end)
  if not status then
    self:debug('turnOff', err)
    self:log('Error: unable to turnOff!')
  end
end
--! [private] wakeUpDeadDevice - R�veiller le module
--!@return none
function FilPiloteZMNHJA2:wakeUpDeadDevice()
  local status, err = pcall(function() 
    return self:updateModeStatus()
  end)
  if not status then
    self:debug('turnOff', err)
    self:log('Error: unable to wakeUp!')
  end
end
--! [private] set value
--!param value: the value
--!@return none
function FilPiloteZMNHJA2:setValue(value)
  local status, err = pcall(function()
    local mode = self:getCommandByRange(value)
    return self:dispatch(mode)
  end)
  if not status then
    self:debug('setValue', err)
    self:log('Error: unable to set mode!')
  end
end
--! [private] set energy
--!param value: the value
--!@return none
function FilPiloteZMNHJA2:setEnergy(value)
  local status, err = pcall(function()
    self:updateProperty('energy', value)
  end)
  if not status then
    self:debug('setEnergy', err)
    self:log('Error: unable to set energy!')
  end
end
--! [private] set power
--!param value: the value
--!@return none
function FilPiloteZMNHJA2:setPower(value)
  local status, err = pcall(function()
    self:updateProperty('power', value)
  end)
  if not status then
    self:debug('setPower', err)
    self:log('Error: unable to set power!')
  end
end