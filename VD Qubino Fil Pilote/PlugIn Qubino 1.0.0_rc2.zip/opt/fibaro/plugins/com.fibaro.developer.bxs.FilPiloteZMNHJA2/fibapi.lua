-- File fibapi.lua
-- Version 1.0.1, stable
--
-- Copyright (C) 2014 by Jean-Christophe Vermandé (Krikroff), all rights reserved.
--
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:
-- 
-- The above copyright notice and this permission notice shall be included in
-- all copies or substantial portions of the Software.
-- 
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
-- THE SOFTWARE.`

--! fibapi object

fibapi = {
  _version = '1.0.1'
}

fibapi.scheme = 'http'
fibapi.host = '127.0.0.1'
fibapi.port = 11111
fibapi.timeout = 2000

--! fibapi may return the following HTTP response codes cf. http://developer.fibaro.com/docs/fghc-restfibapi
fibapi.responseCodes = {
  [200] = 'OK',
  -- Undocumented by Fibaro (Occures when global variable being created)
  [201] = 'Created - the request has been fulfilled and resulted in a new resource being created.',
  -- Undocumented by Fibaro (Occures when the processing has not been completed)
  [202] = 'Accepted – the request has been accepted for processing, but the processing has not been completed',
  [400] = 'Bad request – missing parameter',
  [401] = 'Unauthorized – authentication required',
  [403] = 'Forbidden – valid request, no server response',
  [404] = 'Not found – no content',
  [405] = 'Method not allowed – no content',
  -- Undocumented by Fibaro (Occures when trying to add existing global variable)
  [409] = 'Conflict - the request could not be processed because of conflict in the request',
  -- Undocumented by Fibaro
  [423] = 'Locked - the resource that is being accessed is locked.',
  [500] = 'Internal server error – unexpected condition',
  [501] = 'Not implemented – no content',
  [502] = 'Bad gateway – invalid response from the server',
  [503] = 'Service unavailable – server overloaded or temporarily down for maintenance',
  [504] = 'Gateway timeout – no timely response from the server',
  [0] = 'Unknown'
}
--! [private] Create response object
--!@param response: [object] The raw response from the fibapi
--!@param clock: [time] The clock (cpu time) when request started
--!@return [object] The custom response object
function fibapi.createSuccessResponseObject(response, clock)
  clock = clock or os.clock()
  -- use lambda
  return  { 
    status = response.status or 0, 
    description = fibapi.responseCodes[tonumber(response.status)] or 'Unknown',
    data = response.data,
    sizeOf = string.len(response.data or '') or 0,
    elapsedTime = string.format('%.3f', os.clock() - clock)
  }
end
--! Handle fibapi request
--!@param url: [string] The full url eg:/api/settings/info
--!@param options: [string] The options object for the request (GET/PUT/DELETE/POST, Body message, timeout)
--!@param success: [function] The callback function called after a successful connection.
--!@param error: [function] The callback function called after a faild connection.
--!@return A list containing one item per deleted resource.
function fibapi.request(url, options, success, error)
  local clock = os.clock()
  local httpClient = net.HTTPClient( { fibapi.timeout } )
  httpClient:request(url, {
      success = function(response)
        if (success and type(success) == 'function' ) then
          -- create custom response object
          success( fibapi.createSuccessResponseObject(response, clock) )
        else
          print('callback not found!')
        end
        httpClient = nil
      end,
      error = function(err)
        if (error and type(error) == 'function') then
          error(err)
        else
          print('callback not found!')
        end
        httpClient = nil
      end,
      options = options
    });
end
--! Deleting data from the Home Center controller.
--!@param ressource: [string] The Rest API url eg:/api/settings/info
--!@param success: [function] The callback function called after a successful connection.
--!@param error: [function] The callback function called after a faild connection.
--!@return A list containing one item per deleted resource.
function fibapi.delete(ressource, success, error)
  if (ressource == nil or tostring(ressource) == '') then
    if (error) then
      error('path cannot be empty string!')
    end
  end
  local url = string.format('%s://%s:%d%s', fibapi.scheme, fibapi.host, fibapi.port, ressource)  
  local options = {
    method = 'DELETE'
  }
  fibapi.request(url, options, success, error)
end
--! Modifying existing data on the Home Center controller.
--!@param ressource: [string] The Rest API url eg:/api/settings/info
--!@param body: [string] The message body (The message body must be formatted using JSON.)
--!@param success: [function] The callback function called after a successful connection.
--!@param error: [function] The callback function called after a faild connection.
--!@return A list containing one item per modified parameter.
function fibapi.put(ressource, body, success, error)
  if (ressource == nil or tostring(ressource) == '') then
    if (error) then
      error('path cannot be empty string!')
    end
  end
  local url = string.format('%s://%s:%d%s', fibapi.scheme, fibapi.host, fibapi.port, ressource)
  local options = {
    method = 'PUT',
    headers = {
      ["content-type"] = 'application/json'
    },
    data = body
  }
  fibapi.request(url, options, success, error)
end
--! Adding new data to the Home Center controller.
--!@param ressource: [string] The Rest API url eg:/api/settings/info
--!@param body: [string] The message body (The message body must be formatted using JSON.)
--!@param success: [function] The callback function called after a successful connection.
--!@param error: [function] The callback function called after a faild connection.
--!@return A list containing one item per created resource.
function fibapi.post(ressource, body, success, error)
  if (ressource == nil or tostring(ressource) == '') then
    if (error) then
      error('path cannot be empty string!')
    end
  end
  local url = string.format('%s://%s:%d%s', fibapi.scheme, fibapi.host, fibapi.port, ressource)  
  local options = {
    method = 'POST',
    headers = {
      ["content-type"] = 'application/json'
    },
    data = body
  }
  fibapi.request(url, options, success, error)
end
--! Reading specific data from the Home Center controller.
--!@param ressource: [string] The Rest API url eg:/api/settings/info
--!@param success: [function] The callback function called after a successful connection.
--!@param error: [function] The callback function called after a faild connection.
--!@return JSON containing the requested resource.
function fibapi.get(ressource, success, error)
  if (ressource == nil or tostring(ressource) == '') then
    if (error) then
      error('path cannot be empty string!')
    end
  end
  local url = string.format('%s://%s:%d%s', fibapi.scheme, fibapi.host, fibapi.port, ressource)  
  local options = {
    method = 'GET'
  }
  fibapi.request(url, options, success, error)
end
--eof