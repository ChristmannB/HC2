-------------------------------------------------------------------------------------------
-- Name: FilPiloteZMNHJA2 main
-- Type: Class
-- Version: 1.0.0 RC2
-- Release date: 10-10-2014
-- Author: Jean-Christophe Vermand� (Krikroff)
-------------------------------------------------------------------------------------------
-- Release notes:
--[[
-- Version 1.0.0 RC2
-- Compatible avec le panneau "Linked device" Chauffage.
-- Support de la mesure d'�nergie (compatible avec le panneau �nergie) et de puissance par mise � jour en push depuis une passerelle externe (Merci Christophe Aka Lazer pour cette tr�s bonne id�e :))
-- Support du retour d'�tat du module z-wave
-- Support de l'�tat "noeud mort"
-- Support de la sonde de temp�rature DS18B20 si pr�sente sur le module Fil Pilote
-- Correction du bug de mise � jour de la propri�t� log sur la version 4.018 b�ta
-- Correction du probl�me d'affichage des caract�res accentu�s et sp�ciaux
-- Inversion des modes pour correspondre � la r�vision du module en version 1.2
-- api action wakeUpDeadDevice (support de la commande "wakeUpDeadDevice" pour un r�veil forc� du plugin)
-- api action setMode(arg) (passage en argument du mode en num�rique 6: Arr�t, 5: Hors Gel, 4: Eco, 3: Confort -2�C, 2: Confort -1�C, 1: Confort)
-- api action turnOn() (r�pond � la commande turnOn et demande le mode Confort)
-- api action turnOff() (r�pond � la commande turnOff et demande le mode Arr�t / D�lestage)
-- api action setValue(arg) (r�pond � la commande setValue et demande la mise � jour du mode)
-- api action setEnergy(arg) (passage en argument de la valeur "energie")
-- api action setPower(arg) (passage en argument de la valeur "puissance")

-- API exemples:
-- Passage en Hors Gel : POST api/devices/DEVICE_ID/action/setMode {"args":[5]}
-- Mise en marche Confort : POST api/devices/DEVICE_ID/action/turnOn
-- Passage en mode D�lestage: POST api/devices/DEVICE_ID/action/turnOff
-- Passage d'une valeur "�nergie" : POST api/devices/DEVICE_ID/action/setEnergy {"args":[20.0]}
-- Passage d'une valeur puissance : POST api/devices/DEVICE_ID/action/setPower {"args":[100.0]}

--]]
-------------------------------------------------------------------------------------------
-- Todo notes:
--[[

--]]

--! includes
require('FilPiloteZMNHJA2')

--! Creates handler for $safeprojectname$ (located in $safeprojectname$.lua file) class.
main = FilPiloteZMNHJA2(plugin.mainDeviceId)

--! Array that contains functions assigned to user interface elements in view tab.
uiBinding = {
  --! Actions
  ["modeConfort"] = function() main:setMode(1) end,
  ["modeConfortMinus1"] = function() main:setMode(2) end,
  ["modeConfortMinus2"] = function() main:setMode(3) end,
  ["modeEco"] = function() main:setMode(4) end,
  ["modeHorsGel"] = function() main:setMode(5) end,
  ["modeArret"] = function() main:setMode(6) end
}

function isNumeric(value)
  if (value) then
    if (type(value)=='number') then
      return true
    elseif (type(value)=='string') then
      if (value == '') then
        return false
      else
        if tonumber(value) ~= nil then
          return true
        end    
      end
    end
  end
  return false
end

--! This function is usually used for handling an event assigned to the elements (button, select, etc.) at "Advanced" tab.
-- However this function may be called via any http client by constructing a request as described here.
-- Users of our system may also call such function for example by scenes.
-- Scene developer may call function xx by sending the POST request: 
-- POST api/devices/DEVICE_ID/action/ACTION_NAME {"args":["arg1", ..., "argN"]}
function onAction(deviceId, action)
  main:callAction(action.actionName, unpack(action.args))
end

--! Function that is usually used for handling an event assigned to one of the handlers (button, select, switch, etc.) at "General" tab.
function onUIEvent(deviceId, event)
	local callback = uiBinding[event.elementName]	
	if (callback) then
		callback(event)
	end
end

--! Handle "Save" event performed by the user at plugin's "General" tab. 
function configure(deviceId, config)
  local modified = false

  if (config.deviceID) then
    if (main:updateProperty('deviceID', config.deviceID)) then
      modified = true
    end
	end

  if (config.defaultMode) then
    if (main:updateProperty('defaultMode', config.defaultMode)) then
      modified = true
    end
	end

	if (config.pollingInterval) then
    if (isNumeric(config.pollingInterval) ~= true) then
      if (main:updateProperty('pollingInterval', tostring(main.DEFAULT_POLLING_INTERVAL))) then
        modified = true
      end
    else
      if (main:updateProperty('pollingInterval', tostring(config.pollingInterval))) then
        modified = true
      end
    end
  else
    if (main:updateProperty('pollingInterval', tostring(main.DEFAULT_POLLING_INTERVAL))) then
      modified = true
    end
	end

	if modified then
		main:updateConfig()
	end
end