-------------------------------------------------------------------------------------------
-- Name: async
-- File async.lua
-- Type: Library and Class
-- Version 1.0.3, stable
-- Release date: 10-01-2014
--
-- Copyright (C) 2014 by Jean-Christophe Vermandé (Krikroff), all rights reserved.
--
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:
-- 
-- The above copyright notice and this permission notice shall be included in
-- all copies or substantial portions of the Software.
-- 
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
-- THE SOFTWARE.`
-------------------------------------------------------------------------------------------

--! async object
async = {
  _version = '1.0.3',  
  timer = {		--! async.timer object
    ref = { }
  }, 
  fn = {		--! async.fn object
    _version = '1.0.2'
  }
}
--! generate unique identifier
--@ param name The name of the uid
--@ return The unique identifier (*String)
function async:generateUID(name)
  local uid = string.format('%s-%s-%s', name or 'async', 
    os.time(), math.random(100000))
  if (self.timer.ref[id]) then
    self:generateUID()
  end
  return uid
end
--! Number of timer in object
--@ return number of timers
function async.timer:count()
  local n = 0
  for i, v in pairs( self.ref ) do
    n = n + 1
  end
  return n
end
--! Stop all timers
-- @ return none
function async.timer:stopAll()
  if (self.ref and self:count() > 0) then
    for i, v in pairs( self.ref ) do
      v:stop()
    end
  end
end
--! The Timer class's constructor.
--@ description Create a new timer object, help to generates recurring events in an application.
--@ param id Unique identifier for the timer object
--@ return timer object
--[[
---------------------------------------
-- Example: timer.Interval()
---------------------------------------
local t1 = async.timer.Interval()
t1.debug = true
local t2 = async.timer.Interval()
t2.debug = true
-- count timers
print('Number of timer: '..async.timer:count())
-- Subscribe to events
t1:registerEvent('start', function(time) print('start timer event at ' .. time) end)
t1:registerEvent('stop', function(time) print('stop timer event at ' .. time) end)
t1:registerEvent('beforeStop', function(time) print('beforeStop timer event at ' .. time) end)
t1:registerEvent('tick', function(id, tid, difftime) print('tick (1) id:'..id..' timeoutId: ' .. tid .. ' since ' .. os.date("!%X", difftime) ) end)
t2:registerEvent('tick', function(id, tid, difftime) print('tick (2) id:'..id..' timeoutId: ' .. tid .. ' since ' .. os.date("!%X", difftime)) end)
t2:registerEvent('stop', function(time) print('stop timer event at ' .. time) end)
-- Start timers
t1:start(1000, 20*1000); -- tick every 1 second
t2:start(2000, 10*1000); -- tick every 2 seconds
-- Stop all times
--async.timer:stopAll()
--]]
function async.timer.Interval(id)
  -- # Defaults...
  local self = {
    _version = '1.0.3'  
  }
  id = id or async:generateUID('timer')  -- fix id
  assert(not async.timer.ref[id], "Interval(id*) ["..id.."] already exists in the index")
  -- # Private variables 
  local startAt = 0
  local timeoutId = nil
  local interval = nil
  local events = { 
    ['start'] = {}, 		-- start
    ['stop'] = {}, 			-- stop
    ['tick'] = {}, 			-- tick
    ['beforeStop'] = {} 	-- before stop
  }
  -- # Public variables
  self.debug = false
  self.enabled = false
  -- # Getters
  self.getId = function() 
    return id 
  end
  -- # Other methods
  
  --! Helper method to trace
  --@ value The value or template
  --@ args Arguments if value is a template
  --@ return print
  function self:trace(value, ...)
    if (self.debug) then
      if (value~=nil) then
        return print(string.format(value, ...))
      end
    end
  end
  --! Register event
  --@ name The name of the event
  --@ callback The function to add for the event name
  --@ return none
  function self:registerEvent(name, callback)
    assert(events[name], "Interval:registerEvent(name*, callback) unknown event")
    assert(type(callback)=='function',"Interval:registerEvent(name, callback*) callback is required")
    events[name][id] = callback
  end
  --! Unregister event
  --@ name The name of the event
  --@ callback The function to remove for the event name
  --@ return none
  function self:unregisterEvent(name, callback)
    assert(events[name], "Interval:unregisterEvent(name*, callback) unknown event")
    if (events[name][id]) then
      events[name][id] = {}
    else
      self:trace("<font color='red'>Cannot unregister ".. name .." event</font>")
    end
  end
  --! Unregister all events
  --@ return none
  function self:unregisterAllEvents()
    for i, v in pairs( events ) do
      self:trace('Unregister ' .. i .. ' timer id:'..id)
      events[i][id] = {}
    end
  end
  --! Private method
  --@ return none
  function self:_pcall(method, warning, ...)
    if (method and type(method)=='function') then
      local status, err = pcall(method, ...)
      if not status then
        self:trace("<font color='red'>Error: "..err.."</font>")
      end
    else
      if (warning) then
        self:trace("<font color='red'>Warning: method missing!</font>")
      end
    end
  end
  --! Private method
  --@ return none
  function self:_tick()
    local interval = self.interval
    self.timeoutId = setTimeout(function()      
        self:_pcall(events['tick'][id], true, id, self.timeoutId, os.time()-self.startAt)
        if (self.enabled == true) then
          self:_tick() -- restart
        else
          self:stop()
        end
      end, interval)
  end
  --! Starts raising the tick event by setting enabled to true.
  --@ param interval Timer interval
  --@ param duration Timer duration, infinite timer if nil
  --@ return none
  function self:start(interval, duration)
    self.startAt = os.time()
    self.interval = interval or 1000 -- 1000ms default time interval
    self.enabled = true
    if (duration) then
      setTimeout(function() 
          self:stop();
        end, duration)
      self:trace("<font color='green'>Start timer id:%s with %d ms interval for %d ms</font>", self.id, self.interval, duration)
    else    
      self:trace("<font color='green'>Start timer id:%s with %d ms interval</font>", self.id, self.interval)
    end
    self:_pcall(events['start'][id], false, os.time())
    self:_pcall(events['tick'][id], true, id, 0, os.time()-self.startAt)
    self:_tick()
  end
  --! Stops raising the tick event by setting enabled to false.
  --@ return none
  function self:stop()
    self:_pcall(events['beforeStop'][id], false, os.time())
    if (self.timeoutId) then
      clearTimeout(self.timeoutId)
      --self.timeoutId = nil
      self.enabled = false
      self:_pcall(events['stop'][id], false, os.time())
      self:trace("<font color='green'>Timer id:%s is stopped</font>", id)
    end
  end
  -- Maintains a reference in global object async.timer
  async.timer.ref[id] = self
  -- Return object
  return async.timer.ref[id]
end
-- Eof class Interval

--! static method, waiting for a condition to be effective to execute the callback
--!@param condition (required) The condition
--!@param fn (required) The function that will be executed
--!@param milliseconds (optional) The number of milliseconds to wait before executing the code
--!@return An integer with the ID value of the timer that is set. Use this value with the clearTimeout() method to cancel the timer.
--[[
---------------------------------------
-- Example: fn.wait
---------------------------------------
local isLogged = false
print('We try to connect you, please wait...')
async.fn.wait( function() -- we can use lambda (anonymous function)
    return (isLogged==true) 
  end, 
  function()
    print('You are now logged in')     
  end)
async.fn.Timeout(8000, function() isLogged = true end):start()
--]]
function async.fn.wait(condition, fn, milliseconds)
  assert(type(condition)=='function', 'wait(condition*, fn, milliseconds) condition should be a function')
  assert(type(fn)=='function', 'wait(condition, fn*, milliseconds) fn should be a function')
  if (condition()) then
    fn()
    return 0
  else
    return setTimeout(function() 
        async.fn.wait(condition, fn, milliseconds) 
      end, tonumber(milliseconds or 300))
  end
end
--! Applies a function to a list of arguments
--!@param fn [function] The function to apply arguments.
--!@param scope (optional) [object] The self reference in which the function is executed.
--!@param vargs (optional) The list of arguments
--[[
---------------------------------------
-- Example: fn.apply
---------------------------------------
object = {}
function object:alert(s)
  print('Alert: ' .. s)
end
async.fn.apply(object.alert, object, 'Door is open!')
--]]
function async.fn.apply(fn, scope, ...)
  if (scope) then
    return fn(scope, ...)
  end
  return fn(...)
end
--! Calls function after the number of millseconds specified, optionally in a specific scope
--!@param fn [function] The function to defer.
--!@param milliseconds [number] The number of milliseconds for the setTimeout call (if less than or equal to 0 the function is executed immediately)
--!@param args (optional) [table] Arguments for the call
--!@param scope (optional) [object] The self reference in which the function is executed.
--!@return An integer with the ID value of the timer that is set. Use this value with the clearTimeout() method to cancel the timer.
--[[
---------------------------------------
-- Example: fn.defer
---------------------------------------
hello = {}
function hello:say(name, message)
  print('hello ' .. name .. ". " .. message .. "?")
end
-- executes after 3,5 seconds (scope: hello object):
async.fn.defer(hello.say, 3500, {'Tom', 'how are you (defered in other scope)'}, hello)

function sayHello(name)
  print('hello ' .. name)
end
-- executes immediately:
sayHello('Tom (executes immediately:)');
-- executes after 3 seconds:
async.fn.defer(sayHello, 3000, {'Tom (executes after 3 seconds)'})

-- deferring execution of an anonymous function:
async.fn.defer(function()
    print('Hello fibaro guys (executes lambda after 500ms)')
end, 500);
--]]
function async.fn.defer(fn, milliseconds, args, scope)
  --print('deferring execution ')
  local self = {}
  assert(type(fn)=='function', 'defer(fn*, milliseconds, args, scope) fn should be a function')
  assert(type(milliseconds)=='number', 'defer(fn, milliseconds*, args, scope) milliseconds should be a number')
  --self.fn = async.fn.bind(fn, obj, args, appendArgs);
  self.fn = function ()
    if (args and type(args)=='table') then
      return async.fn.apply(fn, scope, unpack(args))
    end
    if (scope) then
      return fn(scope)
    end
    return fn()
  end
  if (milliseconds > 0) then
    return setTimeout(self.fn, milliseconds)
  end
  self.fn()
  return 0
end
--! Creates a delegate (callback) which, when called, executes after a specific delay.
--!@param fn [function] The function which will be called on a delay when the returned function is called
--!@param milliseconds [number] The number of milliseconds to defer execution by whenever called.
--!@param args (optional) [table] Arguments for the call. 
--!@param scope (optional) [reference] The scope used by the function at execution time.
--!@return [function] A function which, when called, executes the original function after the specified delay.
--[[
---------------------------------------
-- Example: fn.createDelayed
---------------------------------------
local delagate1 = async.fn.createDelayed(function() print('delayed delagate 1') end, 2000)
local delagate2 = async.fn.createDelayed(function(message) print('delayed delagate 2, message:' .. message) end, 8000,  {' hello !'})
delagate1()
delagate2()
--]]
function async.fn.createDelayed(fn, milliseconds, args, scope)
  --print('create delayed delegate (callback)')
  local self = {}
  assert(type(fn)=='function', 'createDelayed(fn*, milliseconds, args, scope) fn should be a function')
  assert(type(milliseconds)=='number', 'createDelayed(fn, milliseconds*, args, scope) milliseconds should be a number')
  --self.fn = async.fn.bind(fn, obj, args, appendArgs);
  self.fn = function ()
    if (args and type(args)=='table') then
      return async.fn.apply(fn, scope, unpack(args))
    end    
    --print('execute function')
    if (scope) then
      return fn(scope)
    end
    return fn()
  end
  return (function()    
    if (milliseconds > 0) then
      return setTimeout(self.fn, milliseconds)
    end
    self.fn()
    return 0
  end)
end
--! Executes a combined function (sequence) with specified interval
--!@param sequence array: item paramerters: fn (function), delayed (milliseconds), scope (object or reference), args (table)
--!@return none
--[[
---------------------------------------
-- Example: fn.delayedSequence
---------------------------------------
async.fn.delayedSequence({
    {fn=function() print('1 - 0') end, delayed = 0},
    {fn=function() print('2 - 1000') end, delayed = 1000},
    {fn=function() print('3 - 1000') end, delayed = 1000},
    {fn=function(t) print('4 - ' .. t) end, delayed = 1000, args = {1000}}
  })
--]]
function async.fn.delayedSequence(sequence)
  assert(type(sequence)=='table', 'delayedSequence(sequence*) sequence should be a table')
  local t = 0
  for i, v in pairs(sequence) do
    if type(v) == "table" then
      assert(type(v.fn)=='function', 'delayedSequence(sequence*) fn should be a function')
      assert(type(v.delayed)=='number', 'delayedSequence(sequence*) delayed should be a number (milliseconds) ')
      t = t + v.delayed
      async.fn.defer(v.fn, t, v.args or nil, v.scope or nil)
    end
  end
end

--! The Timeout class's constructor.
--!@param timeout
--!@param callback
--!@return new 'instance'
--[[
---------------------------------------
-- Example: fn.Timeout
---------------------------------------
local t1 = async.fn.Timeout(2000, function() print('Async timeout t1 raised!') end)
local t2 = async.fn.Timeout(4000, function() print('Async timeout t2 raised!') end):start()
local t3 = async.fn.Timeout()
t3.setCallback(function() print('Async timeout t3 raised!') end)
t3.setTimeout(6000)
local t3_timeoutId = t3:start()

print('t1 timeout id: '..t1:start())
print('t2 timeout id: '..t2)
print('t3 timeout id: '..t3_timeoutId)
--]]
function async.fn.Timeout(timeout, callback)
  local self = { 
    _version = '1.0.0' 
  }
  -- # Private variables
  timeout = tonumber(timeout or 0)
  callback = callback or function() end
  -- # Getters
  self.getTimeout = function() 
    return timeout 
  end
  self.getCallback = function() 
    return callback 
  end  
  -- # Setters
  self.setTimeout = function(value) 
    timeout = tonumber(value or 0) 
  end
  self.setCallback = function(value) 
    callback = value or function() end
  end
  -- # Other methods
  function self:start()
    assert(type(callback)=='function', 
      'Timeout:start() callback should be a function!')
    return setTimeout(callback, timeout)
  end
  return self
end
-- Eof class Interval